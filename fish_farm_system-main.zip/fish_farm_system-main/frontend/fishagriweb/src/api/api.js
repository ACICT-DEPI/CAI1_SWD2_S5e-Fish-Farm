export const BASE_URL = "http://localhost:9000/";

export function sleep(ms) {
  return new Promise((resolve) => setTimeout(resolve, ms));
}
